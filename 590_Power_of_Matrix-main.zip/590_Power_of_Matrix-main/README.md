# 590 Power of 5x5 Matrix
This repository consisty flask app running on ec2, python code that running on lambda function and text file for sending request.





![last_arch](https://user-images.githubusercontent.com/57816597/209660066-e408f41e-93fa-45cc-82b5-04bccb8c6d8f.png)
